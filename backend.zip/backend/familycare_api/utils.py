import json
import secrets
from datetime import timedelta
from decimal import Decimal

from django.http import HttpRequest
from django.utils import timezone


def canonical_phone(phone: str) -> str:
    digits = "".join(character for character in str(phone or "") if character.isdigit())
    if len(digits) == 9:
        return f"998{digits}"
    if len(digits) >= 12 and digits.startswith("998"):
        return digits[-12:]
    return digits


def format_phone(phone: str) -> str:
    digits = canonical_phone(phone)
    if len(digits) == 12 and digits.startswith("998"):
        return f"+998 {digits[3:5]} {digits[5:8]} {digits[8:10]} {digits[10:12]}"
    return str(phone or "").strip()


def relative_time_label(value) -> str:
    if not value:
        return ""

    now = timezone.localtime(timezone.now())
    current = timezone.localtime(value)
    delta = now - current

    if delta < timedelta(minutes=1):
        return "Hozirgina"

    minutes = int(delta.total_seconds() // 60)
    if minutes < 60:
        return f"{minutes} daqiqa oldin"

    hours = minutes // 60
    if hours < 24:
        return f"{hours} soat oldin"

    days = hours // 24
    return f"{days} kun oldin"


def next_check_in_label(time_value) -> str:
    if not time_value:
        return ""
    return f"{time_value:%H:%M} da umumiy check-in"


def as_float(value) -> float:
    if isinstance(value, Decimal):
        return float(value)
    if value is None:
        return 0.0
    return float(value)


def parse_json_body(request: HttpRequest) -> dict:
    if not request.body:
        return {}

    try:
        payload = json.loads(request.body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("JSON body noto'g'ri.") from exc

    if not isinstance(payload, dict):
        raise ValueError("JSON body object bo'lishi kerak.")

    return payload


def pick(payload: dict, *keys, default=None):
    for key in keys:
        if key in payload:
            return payload[key]
    return default


def generate_token_key() -> str:
    return secrets.token_hex(24)
