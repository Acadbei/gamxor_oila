from decimal import Decimal

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.db import transaction

from familycare_api.models import (
    ActivityFeedItem,
    AppNotification,
    AuthToken,
    CareProfile,
    Family,
    FamilyInvitation,
    FamilyMember,
    FeedSeverity,
    InvitationStatus,
    MemberStatus,
    NotificationCategory,
    OtpChallenge,
    SosAlert,
    SosAlertStatus,
    SosDelivery,
    TrustedPlace,
)
from familycare_api.services import create_activity, create_notification, ensure_family, sync_self_member


class Command(BaseCommand):
    help = "Seed Family Care backend with demo data that matches the mobile app."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete existing demo records first.")

    @transaction.atomic
    def handle(self, *args, **options):
        if options["reset"]:
            SosDelivery.objects.all().delete()
            SosAlert.objects.all().delete()
            AppNotification.objects.all().delete()
            ActivityFeedItem.objects.all().delete()
            FamilyInvitation.objects.all().delete()
            FamilyMember.objects.all().delete()
            TrustedPlace.objects.all().delete()
            AuthToken.objects.all().delete()
            OtpChallenge.objects.all().delete()
            Family.objects.filter(owner__username__startswith="998").delete()
            CareProfile.objects.filter(user__username__startswith="998").delete()
            User.objects.filter(username__startswith="998").delete()

        owner_user, _ = User.objects.get_or_create(
            username="998903214567",
            defaults={"first_name": "Nodir"},
        )
        owner_profile, _ = CareProfile.objects.get_or_create(
            user=owner_user,
            defaults={
                "full_name": "Nodir Yusupov",
                "phone": "998903214567",
                "address": "Yunusobod, 9-kvartal",
                "emergency_contact": "998907770011",
                "bio": "Oilaviy monitoring, xavfsizlik va SOS boshqaruvi uchun mas'ulman.",
            },
        )
        owner_profile.full_name = "Nodir Yusupov"
        owner_profile.phone = "998903214567"
        owner_profile.address = "Yunusobod, 9-kvartal"
        owner_profile.emergency_contact = "998907770011"
        owner_profile.bio = "Oilaviy monitoring, xavfsizlik va SOS boshqaruvi uchun mas'ulman."
        owner_profile.save()

        family = ensure_family(owner_profile)
        family.name = "Yusupovlar oilasi"
        family.address = "Yunusobod, 9-kvartal"
        family.save()
        sync_self_member(owner_profile)

        member_rows = [
            {
                "name": "Anvar Yusupov",
                "relation": "Dada",
                "age": 61,
                "phone": "998901234567",
                "latitude": Decimal("41.311800"),
                "longitude": Decimal("69.281900"),
                "address": "Yunusobod, 4-daha",
                "place_label": "Uy atrofida",
                "battery_level": 81,
                "steps": 3821,
                "heart_rate": 74,
                "status": MemberStatus.SAFE,
                "note": "Tonggi yurishdan qaytdi.",
                "safe_zone": "Uy hududi",
                "schedule_label": "21:00 dori eslatmasi",
                "avatar_seed": 1,
                "distance_km": Decimal("2.80"),
            },
            {
                "name": "Dilnoza Yusupova",
                "relation": "Ona",
                "age": 56,
                "phone": "998935556677",
                "latitude": Decimal("41.299500"),
                "longitude": Decimal("69.240100"),
                "address": "Chilonzor, 12-kvartal",
                "place_label": "Ishdan qaytish yo'lida",
                "battery_level": 54,
                "steps": 6140,
                "heart_rate": 82,
                "status": MemberStatus.MOVING,
                "note": "Transportda harakatlanmoqda.",
                "safe_zone": "Ish va uy yo'nalishi",
                "schedule_label": "19:30 oilaviy qo'ng'iroq",
                "avatar_seed": 2,
                "distance_km": Decimal("4.90"),
            },
            {
                "name": "Bobur Yusupov",
                "relation": "O'g'il",
                "age": 14,
                "phone": "998977001122",
                "latitude": Decimal("41.327800"),
                "longitude": Decimal("69.281100"),
                "address": "Maktab, Olmazor tumani",
                "place_label": "Maktab hududi",
                "battery_level": 33,
                "steps": 7280,
                "heart_rate": 92,
                "status": MemberStatus.NEEDS_ATTENTION,
                "note": "Batareya past, zaryad kerak.",
                "safe_zone": "Maktab geozonasi",
                "schedule_label": "16:30 repititor",
                "avatar_seed": 3,
                "distance_km": Decimal("5.70"),
            },
            {
                "name": "O'ktam Yusupov",
                "relation": "Bobo",
                "age": 72,
                "phone": "998914449900",
                "latitude": Decimal("41.300000"),
                "longitude": Decimal("69.200000"),
                "address": "Sergeli, 6-bekat",
                "place_label": "Mahalla dorixonasi",
                "battery_level": 69,
                "steps": 2910,
                "heart_rate": 76,
                "status": MemberStatus.SAFE,
                "note": "Dorilarni olib uyga qaytmoqda.",
                "safe_zone": "Mahalla va dorixona",
                "schedule_label": "18:00 qand nazorati",
                "avatar_seed": 4,
                "distance_km": Decimal("1.90"),
            },
        ]

        bobur_member = None
        for defaults in member_rows:
            member, _ = FamilyMember.objects.update_or_create(
                family=family,
                phone=defaults["phone"],
                defaults=defaults,
            )
            if member.phone == "998977001122":
                bobur_member = member

        candidate_profiles = [
            {
                "username": "998942221100",
                "full_name": "Madina Yusupova",
                "phone": "998942221100",
                "address": "Mirzo Ulug'bek, TTZ-2",
                "avatar_seed": 5,
            },
            {
                "username": "998884107766",
                "full_name": "Jasur Karimov",
                "phone": "998884107766",
                "address": "Shayxontohur, Labzak",
                "avatar_seed": 6,
            },
        ]
        for candidate in candidate_profiles:
            user, _ = User.objects.get_or_create(username=candidate["username"])
            CareProfile.objects.update_or_create(
                user=user,
                defaults={key: value for key, value in candidate.items() if key != "username"},
            )

        if family.activity_items.count() < 3:
            family.activity_items.all().delete()
            create_activity(
                family,
                title="Ilova ishga tushdi",
                subtitle="Xarita va ro'yxatdan o'tish oqimi tayyor.",
                severity=FeedSeverity.POSITIVE,
            )
            create_activity(
                family,
                title="Dilnoza yo'lda",
                subtitle="Chilonzordan Yunusobod tomonga harakatlanyapti.",
                severity=FeedSeverity.NEUTRAL,
                member=FamilyMember.objects.get(family=family, phone="998935556677"),
            )
            if bobur_member:
                create_activity(
                    family,
                    title="Bobur SOS yubordi",
                    subtitle="Maktab hududidan tezkor signal kelgan.",
                    severity=FeedSeverity.WARNING,
                    member=bobur_member,
                )

        if family.notifications.count() < 4:
            family.notifications.all().delete()
            create_notification(
                family,
                title="Profil faol",
                message="Sizning profilingiz ro'yxatdan o'tgan va saqlab qo'yilgan.",
                category=NotificationCategory.SYSTEM,
            )
            create_notification(
                family,
                title="Boburdan SOS signali",
                message="Maktab hududidan tezkor yordam signali keldi.",
                category=NotificationCategory.SAFETY,
            )
            create_notification(
                family,
                title="Yunusobodda kechki ogohlantirish",
                message="Mahalladagi ichki ko'chada shubhali shaxs haqida xabar kelib tushdi.",
                category=NotificationCategory.CRIME,
            )
            create_notification(
                family,
                title="Olmazorda telefon o'g'irlash holati",
                message="Maktab yaqinida telefon tortib olish bo'yicha murojaat qayd etildi.",
                category=NotificationCategory.CRIME,
            )

        if bobur_member and not family.sos_alerts.filter(status=SosAlertStatus.ACTIVE).exists():
            SosAlert.objects.create(
                family=family,
                triggered_by=bobur_member,
                summary="Maktab hududidan tezkor yordam signali keldi.",
                address=bobur_member.address,
                status=SosAlertStatus.ACTIVE,
            )

        if not family.invitations.exists():
            FamilyInvitation.objects.create(
                family=family,
                invited_by=owner_profile,
                platform_profile=CareProfile.objects.filter(phone="998942221100").first(),
                name="Madina Yusupova",
                relation="Singil",
                phone="998942221100",
                status=InvitationStatus.PENDING_ACCEPTANCE,
                is_platform_user=True,
            )

        self.stdout.write(self.style.SUCCESS("Demo data seeded successfully."))
