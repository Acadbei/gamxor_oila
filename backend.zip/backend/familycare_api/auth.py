from functools import wraps

from django.http import JsonResponse
from django.utils import timezone

from .models import AuthToken


TOKEN_TOUCH_INTERVAL_SECONDS = 300


def get_token_from_request(request):
    header = request.META.get("HTTP_AUTHORIZATION", "")
    if not header.startswith("Token "):
        return None

    token_key = header[6:].strip()
    if not token_key:
        return None

    token = (
        AuthToken.objects.select_related("user", "user__care_profile", "user__care_profile__family")
        .filter(key=token_key)
        .first()
    )
    if not token:
        return None
    if token.expires_at <= timezone.now():
        token.delete()
        return None

    now = timezone.now()
    if (
        token.last_used_at is None
        or (now - token.last_used_at).total_seconds() >= TOKEN_TOUCH_INTERVAL_SECONDS
    ):
        token.last_used_at = now
        token.save(update_fields=["last_used_at"])
    return token


def api_login_required(view_func):
    @wraps(view_func)
    def wrapped(request, *args, **kwargs):
        token = get_token_from_request(request)
        if not token:
            return JsonResponse({"detail": "Autentifikatsiya kerak."}, status=401)
        if not hasattr(token.user, "care_profile"):
            return JsonResponse({"detail": "Profil topilmadi."}, status=403)

        request.auth_token = token
        request.profile = token.user.care_profile
        return view_func(request, *args, **kwargs)

    return wrapped
