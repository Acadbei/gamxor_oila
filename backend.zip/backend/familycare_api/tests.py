import json

from django.contrib.auth.models import User
from django.test import Client, TestCase

from .models import BroadcastMessage, CareProfile, FamilyMember, NotificationCategory, SosAlert, SosDelivery
from .services import dispatch_broadcast


class ApiTestCase(TestCase):
    def setUp(self):
        self.client = Client()

    def post_json(self, path, payload, token=None):
        headers = {}
        if token:
            headers["HTTP_AUTHORIZATION"] = f"Token {token}"
        return self.client.post(
            path,
            data=json.dumps(payload),
            content_type="application/json",
            **headers,
        )

    def patch_json(self, path, payload, token=None):
        headers = {}
        if token:
            headers["HTTP_AUTHORIZATION"] = f"Token {token}"
        return self.client.patch(
            path,
            data=json.dumps(payload),
            content_type="application/json",
            **headers,
        )

    def get_json(self, path, token=None):
        headers = {}
        if token:
            headers["HTTP_AUTHORIZATION"] = f"Token {token}"
        return self.client.get(path, **headers)

    def register_owner(self, phone="+998 90 321 45 67", full_name="Nodir Yusupov"):
        request_response = self.post_json("/api/v1/auth/request-code/", {"phone": phone})
        self.assertEqual(request_response.status_code, 201)
        challenge_id = request_response.json()["challengeId"]

        verify_response = self.post_json(
            "/api/v1/auth/verify-code/",
            {"phone": phone, "challengeId": challenge_id, "code": "2580"},
        )
        self.assertEqual(verify_response.status_code, 200)

        register_response = self.post_json(
            "/api/v1/auth/register/",
            {"phone": phone, "fullName": full_name, "challengeId": challenge_id},
        )
        self.assertEqual(register_response.status_code, 201)
        return register_response.json()


class AuthFlowTests(ApiTestCase):
    def test_register_flow_returns_dashboard(self):
        payload = self.register_owner()

        self.assertIn("token", payload)
        dashboard = payload["dashboard"]
        self.assertEqual(dashboard["caregiverName"], "Nodir")
        self.assertEqual(dashboard["profile"]["phone"], "+998 90 321 45 67")
        self.assertEqual(dashboard["selfMember"]["name"], "Nodir Yusupov")
        self.assertEqual(dashboard["selfMember"]["relation"], "Men")
        self.assertEqual(dashboard["trustedPlacesCount"], 0)
        self.assertEqual(dashboard["profile"]["address"], "")
        self.assertEqual(dashboard["familyLabel"], "")


class InvitationTests(ApiTestCase):
    def test_platform_invitation_can_be_accepted(self):
        owner_payload = self.register_owner()
        owner_profile = CareProfile.objects.get(phone="998903214567")

        candidate_user = User.objects.create_user(username="998942221100", password="secret")
        candidate_profile = CareProfile.objects.create(
            user=candidate_user,
            full_name="Madina Yusupova",
            phone="998942221100",
            address="Mirzo Ulug'bek, TTZ-2",
            avatar_seed=5,
        )

        invite_response = self.post_json(
            "/api/v1/invitations/",
            {"phone": "+998 94 222 11 00", "name": "", "relation": "Singil"},
            token=owner_payload["token"],
        )
        self.assertEqual(invite_response.status_code, 201)
        invitation = invite_response.json()
        self.assertTrue(invitation["isPlatformUser"])

        request_response = self.post_json(
            "/api/v1/auth/request-code/",
            {"phone": "+998 94 222 11 00"},
        )
        challenge_id = request_response.json()["challengeId"]
        self.post_json(
            "/api/v1/auth/verify-code/",
            {"phone": "+998 94 222 11 00", "challengeId": challenge_id, "code": "2580"},
        )
        login_response = self.post_json(
            "/api/v1/auth/login/",
            {"phone": "+998 94 222 11 00", "challengeId": challenge_id},
        )
        self.assertEqual(login_response.status_code, 200)
        self.assertEqual(len(login_response.json()["dashboard"]["incomingInvitations"]), 1)

        accept_response = self.post_json(
            f"/api/v1/invitations/{invitation['id']}/accept/",
            {},
            token=login_response.json()["token"],
        )
        self.assertEqual(accept_response.status_code, 200)

        candidate_profile.refresh_from_db()
        self.assertEqual(candidate_profile.family_id, owner_profile.family_id)
        self.assertTrue(
            FamilyMember.objects.filter(
                family=owner_profile.family,
                phone="998942221100",
                linked_profile=candidate_profile,
                name="Madina Yusupova",
            ).exists()
        )

    def test_waiting_install_invitation_becomes_incoming_after_registration(self):
        owner_payload = self.register_owner()

        invite_response = self.post_json(
            "/api/v1/invitations/",
            {"phone": "+998 90 555 66 77", "name": "Aziza", "relation": "Singil"},
            token=owner_payload["token"],
        )
        self.assertEqual(invite_response.status_code, 201)
        self.assertFalse(invite_response.json()["isPlatformUser"])

        candidate_payload = self.register_owner(
            phone="+998 90 555 66 77",
            full_name="Aziza Karimova",
        )
        incoming = candidate_payload["dashboard"]["incomingInvitations"]
        self.assertEqual(len(incoming), 1)
        self.assertTrue(incoming[0]["isIncoming"])
        self.assertEqual(incoming[0]["familyName"], "")

    def test_invitation_delete_removes_invite(self):
        owner_payload = self.register_owner()

        invite_response = self.post_json(
            "/api/v1/invitations/",
            {"phone": "+998 90 555 66 77", "name": "Aziza", "relation": "Singil"},
            token=owner_payload["token"],
        )
        invitation_id = invite_response.json()["id"]

        response = self.client.delete(
            f"/api/v1/invitations/{invitation_id}/",
            HTTP_AUTHORIZATION=f"Token {owner_payload['token']}",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(CareProfile.objects.get(phone="998903214567").family.invitations.exists())


class SosFlowTests(ApiTestCase):
    def test_trigger_sos_creates_deliveries_and_notification(self):
        owner_payload = self.register_owner()
        token = owner_payload["token"]
        owner_profile = CareProfile.objects.get(phone="998903214567")

        FamilyMember.objects.create(
            family=owner_profile.family,
            name="Anvar Yusupov",
            relation="Dada",
            age=61,
            phone="998901234567",
        )
        FamilyMember.objects.create(
            family=owner_profile.family,
            name="Dilnoza Yusupova",
            relation="Ona",
            age=56,
            phone="998935556677",
        )

        response = self.post_json("/api/v1/sos/trigger/", {}, token=token)
        self.assertEqual(response.status_code, 201)

        alert = SosAlert.objects.get()
        self.assertEqual(alert.triggered_by.phone, "998903214567")
        self.assertEqual(SosDelivery.objects.filter(alert=alert).count(), 2)
        self.assertTrue(
            owner_profile.family.notifications.filter(category=NotificationCategory.SAFETY).exists()
        )


class ProfileSyncTests(ApiTestCase):
    def test_profile_patch_updates_family_and_self_member(self):
        owner_payload = self.register_owner()
        token = owner_payload["token"]
        owner_profile = CareProfile.objects.get(phone="998903214567")

        response = self.patch_json(
            "/api/v1/me/profile/",
            {
                "fullName": "Nodir Karimov",
                "phone": "+998 90 321 45 67",
                "address": "Yunusobod, 7-kvartal",
                "familyLabel": "Karimov oilasi",
            },
            token=token,
        )
        self.assertEqual(response.status_code, 200)

        owner_profile.refresh_from_db()
        self.assertEqual(owner_profile.family.name, "Karimov oilasi")
        self.assertTrue(
            FamilyMember.objects.filter(
                family=owner_profile.family,
                linked_profile=owner_profile,
                name="Nodir Karimov",
                address="Yunusobod, 7-kvartal",
            ).exists()
        )


class BroadcastTests(ApiTestCase):
    def test_dispatch_broadcast_creates_notifications_for_all_families(self):
        first_owner = self.register_owner()
        self.register_owner(phone="+998 91 222 33 44", full_name="Malika Karimova")

        admin_user = CareProfile.objects.get(phone="998903214567").user
        broadcast = BroadcastMessage.objects.create(
            title="Tizim yangilandi",
            message="Bugun barcha foydalanuvchilar uchun yangi xususiyatlar yoqildi.",
            created_by=admin_user,
        )

        dispatch_broadcast(broadcast)

        self.assertEqual(broadcast.delivered_families, 2)
        self.assertEqual(
            CareProfile.objects.get(phone="998903214567").family.notifications.filter(
                title="Tizim yangilandi"
            ).count(),
            1,
        )
        self.assertEqual(
            CareProfile.objects.get(phone="998912223344").family.notifications.filter(
                title="Tizim yangilandi"
            ).count(),
            1,
        )
